# Killstrings Platform Setup Guide

## Quick Start

### 1. Development Setup
```bash
# Clone repository
git clone <your-repo>
cd killstrings-platform

# Backend setup
cd backend
npm install
cp .env.example .env
# Edit .env with your values
npm run dev

# Frontend - just open kill up.html in browser