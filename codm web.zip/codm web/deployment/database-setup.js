// deployment/database-setup.js
const mongoose = require('mongoose');
require('dotenv').config();

async function setupDatabase() {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('✅ Database connected successfully');
        
        // Create initial admin user if none exists
        const User = require('../backend/models/User');
        const adminExists = await User.findOne({ isAdmin: true });
        
        if (!adminExists) {
            const bcrypt = require('bcryptjs');
            const adminUser = new User({
                username: 'admin',
                email: 'admin@killstrings.com',
                password: 'admin123', // Change this immediately!
                isAdmin: true,
                isVerified: true,
                referralCode: 'ADMIN001'
            });
            
            await adminUser.save();
            console.log('✅ Default admin user created');
            console.log('📧 Email: admin@killstrings.com');
            console.log('🔑 Password: admin123');
            console.log('🚨 CHANGE THESE CREDENTIALS IMMEDIATELY!');
        }
        
        console.log('✅ Database setup complete');
        process.exit(0);
    } catch (error) {
        console.error('❌ Database setup failed:', error);
        process.exit(1);
    }
}

setupDatabase();