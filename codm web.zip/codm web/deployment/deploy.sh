#!/bin/bash
# /deployment/deploy.sh

echo "🚀 Starting Killstrings Platform Deployment..."

# Pull latest code
git pull origin main

# Install backend dependencies
cd backend
npm install --production

# Create logs directory
mkdir -p logs

# Start with PM2
pm2 restart pm2.config.js

# Reload nginx
sudo nginx -t && sudo systemctl reload nginx

echo "✅ Deployment Complete!"
echo "📊 Check status: pm2 status"
echo "📝 View logs: pm2 logs killstrings-backend"