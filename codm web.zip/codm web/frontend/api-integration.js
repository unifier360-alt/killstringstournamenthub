// frontend/api-integration.js
class KillstringsAPI {
    constructor() {
        this.baseURL = window.location.hostname === 'localhost' 
            ? 'http://localhost:5000/api'
            : '/api'; // Relative URL for production
        this.token = localStorage.getItem('ks_jwt');
    }

    // Set authentication token
    setToken(token) {
        this.token = token;
        localStorage.setItem('ks_jwt', token);
    }

    // Remove token (logout)
    removeToken() {
        this.token = null;
        localStorage.removeItem('ks_jwt');
        localStorage.removeItem('ks_user');
    }

    // Generic API call method
    async call(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers,
            },
            ...options,
        };

        // Add authorization header if token exists
        if (this.token) {
            config.headers.Authorization = `Bearer ${this.token}`;
        }

        // Stringify body if it's an object
        if (config.body && typeof config.body === 'object') {
            config.body = JSON.stringify(config.body);
        }

        try {
            const response = await fetch(url, config);
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || `HTTP error! status: ${response.status}`);
            }

            return data;
        } catch (error) {
            console.error('API call failed:', error);
            throw error;
        }
    }

    // Auth methods
    async login(email, password) {
        const data = await this.call('/auth/login', {
            method: 'POST',
            body: { email, password }
        });
        
        if (data.token) {
            this.setToken(data.token);
            localStorage.setItem('ks_user', JSON.stringify(data.user));
        }
        
        return data;
    }

    async signup(userData) {
        const data = await this.call('/auth/signup', {
            method: 'POST',
            body: userData
        });
        
        if (data.token) {
            this.setToken(data.token);
            localStorage.setItem('ks_user', JSON.stringify(data.user));
        }
        
        return data;
    }

    async getCurrentUser() {
        return await this.call('/auth/me');
    }

    // Tournament methods
    async getTournaments() {
        return await this.call('/tournaments');
    }

    async getFeaturedTournaments() {
        return await this.call('/tournaments/featured');
    }

    async getTournament(id) {
        return await this.call(`/tournaments/${id}`);
    }

    async createTournament(tournamentData) {
        return await this.call('/tournaments', {
            method: 'POST',
            body: tournamentData
        });
    }

    async joinTournament(tournamentId) {
        return await this.call(`/tournaments/${tournamentId}/join`, {
            method: 'POST'
        });
    }

    // Betting methods
    async getMatches() {
        return await this.call('/betting/matches');
    }

    async placeBet(betData) {
        return await this.call('/betting/place', {
            method: 'POST',
            body: betData
        });
    }

    async getMyBets() {
        return await this.call('/betting/my-bets');
    }

    // Wallet methods
    async getWallet() {
        return await this.call('/wallet');
    }

    async deposit(depositData) {
        return await this.call('/wallet/deposit', {
            method: 'POST',
            body: depositData
        });
    }

    async withdraw(withdrawData) {
        return await this.call('/wallet/withdraw', {
            method: 'POST',
            body: withdrawData
        });
    }

    async transfer(transferData) {
        return await this.call('/wallet/transfer', {
            method: 'POST',
            body: transferData
        });
    }

    // Profile methods
    async getProfile() {
        return await this.call('/profile');
    }

    async updateProfile(profileData) {
        return await this.call('/profile', {
            method: 'PUT',
            body: profileData
        });
    }

    async linkGameUID(gameData) {
        return await this.call('/profile/link-game', {
            method: 'POST',
            body: gameData
        });
    }

    async uploadEvidence(evidenceData) {
        return await this.call('/profile/anti-cheat', {
            method: 'POST',
            body: evidenceData
        });
    }

    // Admin methods (only for admin users)
    async getAdminStats() {
        return await this.call('/admin/dashboard');
    }

    async getAdminUsers() {
        return await this.call('/admin/users');
    }

    async getAdminTransactions() {
        return await this.call('/admin/transactions');
    }

    async approveWithdrawal(transactionId) {
        return await this.call(`/admin/transactions/${transactionId}/approve`, {
            method: 'POST'
        });
    }
}

// Create global API instance
window.KillstringsAPI = new KillstringsAPI();