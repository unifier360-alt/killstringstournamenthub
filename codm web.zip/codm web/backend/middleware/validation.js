const { body, param, query } = require('express-validator');

// User validation
const validateUserRegistration = [
  body('username')
    .isLength({ min: 3, max: 20 })
    .withMessage('Username must be between 3 and 20 characters')
    .matches(/^[a-zA-Z0-9_]+$/)
    .withMessage('Username can only contain letters, numbers, and underscores'),
  
  body('email')
    .isEmail()
    .withMessage('Please provide a valid email')
    .normalizeEmail(),
  
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one lowercase letter, one uppercase letter, and one number')
];

const validateUserLogin = [
  body('email')
    .isEmail()
    .withMessage('Please provide a valid email')
    .normalizeEmail(),
  
  body('password')
    .notEmpty()
    .withMessage('Password is required')
];

// Tournament validation
const validateTournamentCreation = [
  body('name')
    .isLength({ min: 5, max: 100 })
    .withMessage('Tournament name must be between 5 and 100 characters'),
  
  body('game')
    .isIn(['COD Mobile', 'Free Fire', 'Blood Strike', 'PUBG Mobile', 'Fortnite'])
    .withMessage('Please select a valid game'),
  
  body('type')
    .isIn(['solo', 'duo', 'squad', 'team'])
    .withMessage('Please select a valid tournament type'),
  
  body('prizePool')
    .isFloat({ min: 0 })
    .withMessage('Prize pool must be a positive number'),
  
  body('entryFee')
    .isFloat({ min: 0 })
    .withMessage('Entry fee must be a positive number'),
  
  body('maxParticipants')
    .isInt({ min: 2, max: 1000 })
    .withMessage('Max participants must be between 2 and 1000'),
  
  body('startTime')
    .isISO8601()
    .withMessage('Please provide a valid start date and time')
];

// Betting validation
const validateBetPlacement = [
  body('matchId')
    .notEmpty()
    .withMessage('Match ID is required'),
  
  body('selection')
    .notEmpty()
    .withMessage('Selection is required'),
  
  body('amount')
    .isFloat({ min: 1 })
    .withMessage('Bet amount must be at least $1'),
  
  body('odds')
    .isFloat({ min: 1.01 })
    .withMessage('Odds must be greater than 1.00')
];

// Wallet validation
const validateDeposit = [
  body('amount')
    .isFloat({ min: 5 })
    .withMessage('Minimum deposit is $5'),
  
  body('method')
    .isIn(['paystack', 'flutterwave', 'stripe', 'paypal'])
    .withMessage('Please select a valid payment method')
];

const validateWithdrawal = [
  body('amount')
    .isFloat({ min: 10 })
    .withMessage('Minimum withdrawal is $10'),
  
  body('method')
    .isIn(['bank', 'paypal', 'crypto'])
    .withMessage('Please select a valid withdrawal method'),
  
  body('accountDetails')
    .optional()
    .isObject()
    .withMessage('Account details must be an object')
];

const validateTransfer = [
  body('toUsername')
    .notEmpty()
    .withMessage('Recipient username is required'),
  
  body('amount')
    .isFloat({ min: 1 })
    .withMessage('Minimum transfer amount is $1')
];

// Admin validation
const validateAdminAction = [
  param('id')
    .isMongoId()
    .withMessage('Invalid ID format'),
  
  body('action')
    .isIn(['approve', 'reject', 'ban', 'unban', 'suspend'])
    .withMessage('Please provide a valid action')
];

// Anti-cheat validation
const validateEvidenceUpload = [
  body('tournamentId')
    .notEmpty()
    .withMessage('Tournament ID is required'),
  
  body('evidenceType')
    .isIn(['screenshot', 'video'])
    .withMessage('Please select a valid evidence type'),
  
  body('matchId')
    .optional()
    .notEmpty()
    .withMessage('Match ID cannot be empty if provided')
];

module.exports = {
  validateUserRegistration,
  validateUserLogin,
  validateTournamentCreation,
  validateBetPlacement,
  validateDeposit,
  validateWithdrawal,
  validateTransfer,
  validateAdminAction,
  validateEvidenceUpload
};