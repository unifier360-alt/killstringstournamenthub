const axios = require('axios');

// Paystack integration
async function processPaystackDeposit(transaction, email) {
  try {
    const response = await axios.post(
      'https://api.paystack.co/transaction/initialize',
      {
        email,
        amount: transaction.amount * 100, // Convert to kobo
        reference: transaction.reference,
        callback_url: `${process.env.CLIENT_URL}/wallet?success=true`
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return {
      paymentUrl: response.data.data.authorization_url,
      reference: response.data.data.reference
    };
  } catch (error) {
    console.error('Paystack error:', error.response?.data || error.message);
    throw new Error('Payment initialization failed');
  }
}

// Flutterwave integration
async function processFlutterwaveDeposit(transaction, email) {
  try {
    const response = await axios.post(
      'https://api.flutterwave.com/v3/payments',
      {
        tx_ref: transaction.reference,
        amount: transaction.amount,
        currency: 'USD',
        redirect_url: `${process.env.CLIENT_URL}/wallet?success=true`,
        customer: {
          email,
        },
        customizations: {
          title: 'Killstrings Tournament Hub',
          description: `Deposit of $${transaction.amount}`
        }
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return {
      paymentUrl: response.data.data.link,
      reference: response.data.data.tx_ref
    };
  } catch (error) {
    console.error('Flutterwave error:', error.response?.data || error.message);
    throw new Error('Payment initialization failed');
  }
}

// Main deposit processor
async function processDeposit(transaction, method) {
  switch (method) {
    case 'paystack':
      return await processPaystackDeposit(transaction, transaction.userId.email);
    case 'flutterwave':
      return await processFlutterwaveDeposit(transaction, transaction.userId.email);
    case 'card':
    case 'paypal':
      // Implement Stripe/PayPal here
      return { paymentUrl: `${process.env.CLIENT_URL}/payment/${transaction._id}` };
    default:
      throw new Error('Unsupported payment method');
  }
}

// Verify payment
async function verifyPayment(reference, method) {
  try {
    if (method === 'paystack') {
      const response = await axios.get(
        `https://api.paystack.co/transaction/verify/${reference}`,
        {
          headers: {
            Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`
          }
        }
      );

      return response.data.data.status === 'success';
    }
    
    // Add verification for other providers
    
    return false;
  } catch (error) {
    console.error('Payment verification error:', error);
    return false;
  }
}

module.exports = { processDeposit, verifyPayment };