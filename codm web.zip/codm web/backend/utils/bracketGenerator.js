function generateBracket(participants) {
  const shuffled = [...participants].sort(() => Math.random() - 0.5);
  const matches = [];
  
  // Create first round matches
  for (let i = 0; i < shuffled.length; i += 2) {
    matches.push({
      round: 1,
      matchId: `m1_${i/2 + 1}`,
      player1: shuffled[i]?.username || 'BYE',
      player2: shuffled[i + 1]?.username || 'BYE',
      winner: null,
      status: 'pending'
    });
  }
  
  // Generate bracket structure
  const bracket = {
    rounds: [
      {
        round: 1,
        matches: matches
      }
    ],
    createdAt: new Date().toISOString()
  };
  
  return bracket;
}

function advanceWinner(bracket, matchId, winner) {
  // Find match and update winner
  for (let round of bracket.rounds) {
    const match = round.matches.find(m => m.matchId === matchId);
    if (match) {
      match.winner = winner;
      match.status = 'completed';
      
      // Generate next round matches if needed
      generateNextRound(bracket, round.round);
      break;
    }
  }
  
  return bracket;
}

function generateNextRound(bracket, currentRound) {
  const currentMatches = bracket.rounds.find(r => r.round === currentRound).matches;
  const nextRoundNumber = currentRound + 1;
  
  // Check if all matches in current round are completed
  const allCompleted = currentMatches.every(m => m.status === 'completed');
  
  if (allCompleted && currentMatches.length > 1) {
    const nextRoundMatches = [];
    
    for (let i = 0; i < currentMatches.length; i += 2) {
      const match1 = currentMatches[i];
      const match2 = currentMatches[i + 1];
      
      if (match1 && match2) {
        nextRoundMatches.push({
          round: nextRoundNumber,
          matchId: `m${nextRoundNumber}_${i/2 + 1}`,
          player1: match1.winner,
          player2: match2.winner,
          winner: null,
          status: 'pending'
        });
      }
    }
    
    // Add next round to bracket
    const existingNextRound = bracket.rounds.find(r => r.round === nextRoundNumber);
    if (!existingNextRound) {
      bracket.rounds.push({
        round: nextRoundNumber,
        matches: nextRoundMatches
      });
    }
  }
  
  return bracket;
}

module.exports = { generateBracket, advanceWinner };