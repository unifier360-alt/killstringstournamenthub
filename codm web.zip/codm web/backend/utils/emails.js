const nodemailer = require('nodemailer');

// Create transporter
const transporter = nodemailer.createTransporter({
  service: process.env.EMAIL_SERVICE || 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Email templates
const emailTemplates = {
  verification: (verificationLink) => ({
    subject: 'Verify Your Killstrings Account',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #007aff; text-align: center;">Welcome to Killstrings Tournament Hub!</h2>
        <p>Thank you for registering. Please verify your email address to complete your account setup.</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${verificationLink}" 
             style="background: linear-gradient(45deg, #ff3b30, #007aff); 
                    color: white; 
                    padding: 12px 30px; 
                    text-decoration: none; 
                    border-radius: 24px; 
                    font-weight: bold;">
            Verify Email Address
          </a>
        </div>
        <p>If the button doesn't work, copy and paste this link in your browser:</p>
        <p style="word-break: break-all;">${verificationLink}</p>
        <p>This link will expire in 24 hours.</p>
      </div>
    `
  }),

  passwordReset: (resetLink) => ({
    subject: 'Reset Your Killstrings Password',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #007aff; text-align: center;">Password Reset Request</h2>
        <p>You requested to reset your password. Click the button below to create a new password.</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetLink}" 
             style="background: linear-gradient(45deg, #ff3b30, #007aff); 
                    color: white; 
                    padding: 12px 30px; 
                    text-decoration: none; 
                    border-radius: 24px; 
                    font-weight: bold;">
            Reset Password
          </a>
        </div>
        <p>If you didn't request this, please ignore this email.</p>
        <p>This link will expire in 1 hour.</p>
      </div>
    `
  }),

  tournamentJoined: (tournamentName, startTime) => ({
    subject: `You've Joined ${tournamentName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #007aff; text-align: center;">Tournament Registration Confirmed!</h2>
        <p>You have successfully joined <strong>${tournamentName}</strong>.</p>
        <p><strong>Start Time:</strong> ${new Date(startTime).toLocaleString()}</p>
        <p>Good luck! Make sure to be online 15 minutes before the tournament starts.</p>
      </div>
    `
  }),

  betWon: (amount, selection) => ({
    subject: 'Congratulations! Your Bet Won!',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #4cd964; text-align: center;">Bet Winning!</h2>
        <p>Congratulations! Your bet on <strong>${selection}</strong> has won!</p>
        <p style="font-size: 18px; font-weight: bold; color: #4cd964;">
          Amount Won: $${amount}
        </p>
        <p>The amount has been credited to your wallet.</p>
      </div>
    `
  }),

  depositConfirmed: (amount) => ({
    subject: 'Deposit Confirmed',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #4cd964; text-align: center;">Deposit Successful!</h2>
        <p>Your deposit of <strong>$${amount}</strong> has been confirmed and credited to your wallet.</p>
        <p>You can now join tournaments and place bets.</p>
      </div>
    `
  }),

  withdrawalProcessed: (amount) => ({
    subject: 'Withdrawal Processed',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #007aff; text-align: center;">Withdrawal Processed</h2>
        <p>Your withdrawal request for <strong>$${amount}</strong> has been processed.</p>
        <p>The funds should appear in your account within 1-3 business days.</p>
      </div>
    `
  }),

  adminAlert: (title, message) => ({
    subject: `Admin Alert: ${title}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #ff3b30; text-align: center;">${title}</h2>
        <p>${message}</p>
        <p>Please check the admin panel for details.</p>
      </div>
    `
  })
};

// Send email function
async function sendEmail(to, templateName, data) {
  try {
    if (!emailTemplates[templateName]) {
      throw new Error(`Email template '${templateName}' not found`);
    }

    const template = emailTemplates[templateName](...data);
    
    const mailOptions = {
      from: `"Killstrings Tournament Hub" <${process.env.EMAIL_USER}>`,
      to,
      subject: template.subject,
      html: template.html
    };

    const result = await transporter.sendMail(mailOptions);
    console.log(`Email sent to ${to}: ${result.messageId}`);
    return result;
  } catch (error) {
    console.error('Email sending failed:', error);
    throw error;
  }
}

// Specific email functions
async function sendVerificationEmail(email, verificationToken) {
  const verificationLink = `${process.env.CLIENT_URL}/verify-email?token=${verificationToken}`;
  return await sendEmail(email, 'verification', [verificationLink]);
}

async function sendPasswordResetEmail(email, resetToken) {
  const resetLink = `${process.env.CLIENT_URL}/reset-password?token=${resetToken}`;
  return await sendEmail(email, 'passwordReset', [resetLink]);
}

async function sendTournamentJoinedEmail(email, tournamentName, startTime) {
  return await sendEmail(email, 'tournamentJoined', [tournamentName, startTime]);
}

async function sendBetWonEmail(email, amount, selection) {
  return await sendEmail(email, 'betWon', [amount, selection]);
}

async function sendDepositConfirmedEmail(email, amount) {
  return await sendEmail(email, 'depositConfirmed', [amount]);
}

async function sendWithdrawalProcessedEmail(email, amount) {
  return await sendEmail(email, 'withdrawalProcessed', [amount]);
}

async function sendAdminAlert(email, title, message) {
  return await sendEmail(email, 'adminAlert', [title, message]);
}

module.exports = {
  sendEmail,
  sendVerificationEmail,
  sendPasswordResetEmail,
  sendTournamentJoinedEmail,
  sendBetWonEmail,
  sendDepositConfirmedEmail,
  sendWithdrawalProcessedEmail,
  sendAdminAlert
};