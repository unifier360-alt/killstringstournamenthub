const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  balance: { type: Number, default: 0 },
  isAdmin: { type: Boolean, default: false },
  isPremium: { type: Boolean, default: false },
  isVerified: { type: Boolean, default: false },
  profile: {
    codmUID: String,
    freeFireUID: String,
    bloodStrikeUID: String,
    rank: String,
    avatar: String
  },
  referralCode: { type: String, unique: true },
  referredBy: String,
  twoFactorEnabled: { type: Boolean, default: false },
  twoFactorSecret: String,
  createdAt: { type: Date, default: Date.now }
});

const tournamentSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  game: { type: String, required: true },
  type: { type: String, required: true },
  prizePool: { type: Number, required: true },
  entryFee: { type: Number, required: true },
  maxParticipants: { type: Number, required: true },
  currentParticipants: { type: Number, default: 0 },
  participants: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    username: String,
    joinedAt: { type: Date, default: Date.now },
    position: Number,
    score: Number
  }],
  startTime: { type: Date, required: true },
  rules: String,
  status: { type: String, enum: ['upcoming', 'active', 'finished', 'cancelled'], default: 'upcoming' },
  bracket: mongoose.Schema.Types.Mixed,
  winner: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now }
});

const betSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  matchId: { type: String, required: true },
  tournamentId: { type: String, required: true },
  selection: { type: String, required: true },
  odds: { type: Number, required: true },
  amount: { type: Number, required: true },
  potentialWin: { type: Number, required: true },
  status: { type: String, enum: ['active', 'won', 'lost', 'cancelled'], default: 'active' },
  settledAt: Date,
  createdAt: { type: Date, default: Date.now }
});

const transactionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  type: { type: String, enum: ['deposit', 'withdrawal', 'bet', 'tournament_entry', 'transfer', 'winning', 'refund', 'referral'], required: true },
  amount: { type: Number, required: true },
  method: String,
  status: { type: String, enum: ['pending', 'completed', 'failed', 'cancelled'], default: 'pending' },
  reference: String,
  toUser: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  description: String,
  metadata: mongoose.Schema.Types.Mixed,
  createdAt: { type: Date, default: Date.now }
});

const antiCheatSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  tournamentId: { type: String, required: true },
  matchId: String,
  evidenceType: { type: String, enum: ['screenshot', 'video'], required: true },
  filename: String,
  fileUrl: String,
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  adminNotes: String,
  reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  reviewedAt: Date,
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);
const Tournament = mongoose.model('Tournament', tournamentSchema);
const Bet = mongoose.model('Bet', betSchema);
const Transaction = mongoose.model('Transaction', transactionSchema);
const AntiCheat = mongoose.model('AntiCheat', antiCheatSchema);

module.exports = { User, Tournament, Bet, Transaction, AntiCheat };