const paystack = require('paystack')(process.env.PAYSTACK_SECRET_KEY);
const axios = require('axios');

const paymentConfig = {
  paystack: {
    secretKey: process.env.PAYSTACK_SECRET_KEY,
    publicKey: process.env.PAYSTACK_PUBLIC_KEY,
    baseUrl: 'https://api.paystack.co'
  },
  flutterwave: {
    secretKey: process.env.FLUTTERWAVE_SECRET_KEY,
    publicKey: process.env.FLUTTERWAVE_PUBLIC_KEY,
    baseUrl: 'https://api.flutterwave.com/v3'
  },
  stripe: {
    secretKey: process.env.STRIPE_SECRET_KEY,
    publicKey: process.env.STRIPE_PUBLIC_KEY
  }
};

// Commission rates
const commissionRates = {
  platform: 0.05, // 5% platform commission
  betting: 0.02,  // 2% betting commission
  tournament: 0.03 // 3% tournament commission
};

// Payment method configurations
const paymentMethods = {
  paystack: {
    name: 'Paystack',
    countries: ['NG', 'GH', 'KE', 'ZA'],
    currencies: ['NGN', 'USD', 'GHS', 'KES', 'ZAR'],
    minAmount: 1,
    maxAmount: 1000000
  },
  flutterwave: {
    name: 'Flutterwave',
    countries: ['NG', 'GH', 'KE', 'US', 'UK'],
    currencies: ['NGN', 'USD', 'GBP', 'EUR', 'GHS', 'KES'],
    minAmount: 1,
    maxAmount: 1000000
  },
  stripe: {
    name: 'Stripe',
    countries: ['US', 'UK', 'CA', 'AU', 'EU'],
    currencies: ['USD', 'EUR', 'GBP', 'CAD', 'AUD'],
    minAmount: 0.5,
    maxAmount: 999999.99
  }
};

module.exports = {
  paymentConfig,
  commissionRates,
  paymentMethods
};