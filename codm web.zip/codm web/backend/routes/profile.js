const express = require('express');
const { User, AntiCheat } = require('../config/database');
const { auth } = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

const router = express.Router();

// Get user profile
router.get('/', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .select('-password -twoFactorSecret');
    
    res.json(user);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update profile
router.put('/', auth, [
  body('username').optional().isLength({ min: 3, max: 20 }),
  body('profile.codmUID').optional().isLength({ min: 3 }),
  body('profile.freeFireUID').optional().isLength({ min: 3 }),
  body('profile.bloodStrikeUID').optional().isLength({ min: 3 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { username, profile } = req.body;
    const updateData = {};

    if (username && username !== req.user.username) {
      // Check if username is taken
      const existingUser = await User.findOne({ username });
      if (existingUser) {
        return res.status(400).json({ message: 'Username already taken' });
      }
      updateData.username = username;
    }

    if (profile) {
      updateData.profile = { ...req.user.profile, ...profile };
    }

    const user = await User.findByIdAndUpdate(
      req.user._id,
      updateData,
      { new: true }
    ).select('-password -twoFactorSecret');

    res.json({ message: 'Profile updated successfully', user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Link game UID
router.post('/link-game', auth, [
  body('game').isIn(['codm', 'freefire', 'bloodstrike']),
  body('uid').isLength({ min: 3 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { game, uid } = req.body;
    const fieldMap = {
      codm: 'codmUID',
      freefire: 'freeFireUID',
      bloodstrike: 'bloodStrikeUID'
    };

    const updateField = fieldMap[game];
    if (!updateField) {
      return res.status(400).json({ message: 'Invalid game specified' });
    }

    // Verify UID (this would integrate with game APIs in production)
    const verificationResult = await verifyGameUID(game, uid);
    
    if (!verificationResult.valid) {
      return res.status(400).json({ message: verificationResult.message || 'Invalid game UID' });
    }

    const user = await User.findByIdAndUpdate(
      req.user._id,
      { [`profile.${updateField}`]: uid },
      { new: true }
    ).select('-password -twoFactorSecret');

    res.json({ 
      message: 'Game UID linked successfully', 
      user,
      verified: verificationResult.verified 
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Upload anti-cheat evidence
router.post('/anti-cheat', auth, [
  body('tournamentId').notEmpty(),
  body('evidenceType').isIn(['screenshot', 'video']),
  body('matchId').optional(),
  body('filename').notEmpty()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { tournamentId, evidenceType, matchId, filename } = req.body;

    // In production, you would upload the file to cloud storage (AWS S3, etc.)
    // and get the file URL. For demo, we'll store metadata only.
    
    const evidence = new AntiCheat({
      userId: req.user._id,
      tournamentId,
      matchId: matchId || 'N/A',
      evidenceType,
      filename,
      fileUrl: `/uploads/evidence/${filename}`, // This would be the actual cloud URL
      status: 'pending'
    });

    await evidence.save();

    // Perform basic OCR/AI analysis on the evidence (simplified)
    await analyzeEvidence(evidence);

    res.json({ 
      message: 'Evidence uploaded successfully and submitted for review',
      evidence 
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get user's anti-cheat submissions
router.get('/anti-cheat', auth, async (req, res) => {
  try {
    const evidence = await AntiCheat.find({ userId: req.user._id })
      .sort({ createdAt: -1 })
      .populate('reviewedBy', 'username');
    
    res.json(evidence);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Change password
router.post('/change-password', auth, [
  body('currentPassword').notEmpty(),
  body('newPassword').isLength({ min: 6 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user._id);

    // Verify current password
    const bcrypt = require('bcryptjs');
    const isMatch = await bcrypt.compare(currentPassword, user.password);
    
    if (!isMatch) {
      return res.status(400).json({ message: 'Current password is incorrect' });
    }

    // Hash new password
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(newPassword, salt);

    await user.save();

    res.json({ message: 'Password changed successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Enable/disable 2FA
router.post('/two-factor', auth, [
  body('enabled').isBoolean()
], async (req, res) => {
  try {
    const { enabled } = req.body;
    
    // In production, you would use a library like speakeasy for TOTP
    // This is a simplified version
    
    if (enabled && !req.user.twoFactorEnabled) {
      // Generate 2FA secret (in production, use proper TOTP generation)
      const secret = 'demo_secret_' + Math.random().toString(36).substr(2, 10);
      
      req.user.twoFactorEnabled = true;
      req.user.twoFactorSecret = secret;
    } else if (!enabled) {
      req.user.twoFactorEnabled = false;
      req.user.twoFactorSecret = undefined;
    }

    await req.user.save();

    res.json({ 
      message: `Two-factor authentication ${enabled ? 'enabled' : 'disabled'}`,
      twoFactorEnabled: req.user.twoFactorEnabled,
      ...(enabled && { secret: req.user.twoFactorSecret }) // In production, return QR code URL
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Helper functions
async function verifyGameUID(game, uid) {
  // This would integrate with actual game APIs
  // For demo purposes, we'll simulate verification
  
  const simulations = {
    codm: { valid: uid.length >= 6, verified: true, message: 'CODM UID verified' },
    freefire: { valid: uid.length >= 4, verified: true, message: 'Free Fire UID verified' },
    bloodstrike: { valid: uid.length >= 3, verified: true, message: 'Blood Strike UID verified' }
  };

  return simulations[game] || { valid: false, verified: false, message: 'Game not supported' };
}

async function analyzeEvidence(evidence) {
  // This would perform actual OCR and AI analysis on the uploaded evidence
  // For demo, we'll simulate some analysis
  
  console.log(`Analyzing evidence for cheating patterns: ${evidence.filename}`);
  
  // Simulate AI analysis delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Return analysis results (would be stored in evidence in production)
  return {
    containsSuspiciousElements: Math.random() > 0.8, // 20% chance
    confidence: Math.random(),
    detectedPatterns: []
  };
}

module.exports = router;