const express = require('express');
const { Bet, Tournament, User, Transaction } = require('../config/database');
const { auth } = require('../middleware/auth');

const router = express.Router();

// Get available matches for betting
router.get('/matches', async (req, res) => {
  try {
    const tournaments = await Tournament.find({ 
      status: 'active',
      'participants.1': { $exists: true } // At least 2 participants
    }).populate('participants.userId', 'username');

    const matches = tournaments.map(tournament => {
      const participants = tournament.participants.slice(0, 2); // First two participants
      return {
        id: `m_${tournament.id}`,
        tournamentId: tournament.id,
        tournamentName: tournament.name,
        teams: participants.map(p => p.username),
        odds: [1.8, 2.1], // In real system, calculate based on stats
        startTime: tournament.startTime
      };
    });

    res.json(matches);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Place bet
router.post('/place', auth, async (req, res) => {
  try {
    const { matchId, selection, amount, odds } = req.body;

    // Validate amount
    if (amount <= 0 || amount > req.user.balance) {
      return res.status(400).json({ message: 'Invalid bet amount' });
    }

    // Deduct bet amount from user balance
    req.user.balance -= amount;
    await req.user.save();

    // Create bet
    const bet = new Bet({
      userId: req.user._id,
      matchId,
      selection,
      odds: Number(odds),
      amount: Number(amount),
      potentialWin: Number((amount * odds).toFixed(2))
    });

    await bet.save();

    // Record transaction
    const transaction = new Transaction({
      userId: req.user._id,
      type: 'bet',
      amount: Number(amount),
      status: 'completed',
      description: `Bet on ${selection}`
    });

    await transaction.save();

    res.json({ message: 'Bet placed successfully', bet });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get user bets
router.get('/my-bets', auth, async (req, res) => {
  try {
    const bets = await Bet.find({ userId: req.user._id })
      .sort({ createdAt: -1 })
      .populate('tournamentId');
    
    res.json(bets);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Settle bet (admin)
router.post('/:id/settle', auth, async (req, res) => {
  try {
    if (!req.user.isAdmin) {
      return res.status(403).json({ message: 'Admin access required' });
    }

    const { result } = req.body; // 'won' or 'lost'
    const bet = await Bet.findById(req.params.id).populate('userId');

    if (!bet) {
      return res.status(404).json({ message: 'Bet not found' });
    }

    bet.status = result;
    bet.settledAt = new Date();

    if (result === 'won') {
      // Pay winnings
      bet.userId.balance += bet.potentialWin;
      await bet.userId.save();

      // Record winning transaction
      const transaction = new Transaction({
        userId: bet.userId._id,
        type: 'winning',
        amount: bet.potentialWin,
        status: 'completed',
        description: `Bet winning from ${bet.selection}`
      });

      await transaction.save();
    }

    await bet.save();

    res.json({ message: `Bet settled as ${result}`, bet });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;