const express = require('express');
const { User, Tournament, Transaction, Bet, AntiCheat } = require('../config/database');
const { adminAuth } = require('../middleware/auth');

const router = express.Router();

// Get admin dashboard stats
router.get('/dashboard', adminAuth, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalTournaments = await Tournament.countDocuments();
    const totalVolume = await Transaction.aggregate([
      { $match: { type: 'deposit', status: 'completed' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);
    const pendingWithdrawals = await Transaction.countDocuments({ 
      type: 'withdrawal', 
      status: 'pending' 
    });

    res.json({
      totalUsers,
      totalTournaments,
      totalVolume: totalVolume[0]?.total || 0,
      pendingWithdrawals
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// User management
router.get('/users', adminAuth, async (req, res) => {
  try {
    const users = await User.find()
      .select('-password')
      .sort({ createdAt: -1 });
    
    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Ban/unban user
router.post('/users/:id/ban', adminAuth, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.isBanned = !user.isBanned;
    await user.save();

    res.json({ 
      message: `User ${user.isBanned ? 'banned' : 'unbanned'} successfully`,
      user 
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Tournament management
router.get('/tournaments', adminAuth, async (req, res) => {
  try {
    const tournaments = await Tournament.find()
      .populate('participants.userId', 'username')
      .sort({ createdAt: -1 });
    
    res.json(tournaments);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update tournament status
router.put('/tournaments/:id/status', adminAuth, async (req, res) => {
  try {
    const { status } = req.body;
    const tournament = await Tournament.findOne({ id: req.params.id });

    if (!tournament) {
      return res.status(404).json({ message: 'Tournament not found' });
    }

    tournament.status = status;
    await tournament.save();

    res.json(tournament);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Payment management
router.get('/transactions', adminAuth, async (req, res) => {
  try {
    const transactions = await Transaction.find()
      .populate('userId', 'username email')
      .sort({ createdAt: -1 })
      .limit(100);
    
    res.json(transactions);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Approve withdrawal
router.post('/transactions/:id/approve', adminAuth, async (req, res) => {
  try {
    const transaction = await Transaction.findById(req.params.id)
      .populate('userId');

    if (!transaction || transaction.type !== 'withdrawal') {
      return res.status(404).json({ message: 'Withdrawal transaction not found' });
    }

    // Process withdrawal via payment provider
    // This would integrate with Paystack, Flutterwave, etc.
    
    transaction.status = 'completed';
    await transaction.save();

    res.json({ message: 'Withdrawal approved and processed', transaction });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Anti-cheat evidence review
router.get('/anti-cheat', adminAuth, async (req, res) => {
  try {
    const evidence = await AntiCheat.find({ status: 'pending' })
      .populate('userId', 'username')
      .sort({ createdAt: -1 });
    
    res.json(evidence);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Review anti-cheat evidence
router.post('/anti-cheat/:id/review', adminAuth, async (req, res) => {
  try {
    const { action, notes } = req.body; // action: 'approve' or 'reject'
    const evidence = await AntiCheat.findById(req.params.id);

    if (!evidence) {
      return res.status(404).json({ message: 'Evidence not found' });
    }

    evidence.status = action;
    evidence.adminNotes = notes;
    evidence.reviewedBy = req.user._id;
    evidence.reviewedAt = new Date();

    await evidence.save();

    // If approved, you might want to take additional actions
    // like adjusting tournament results, banning users, etc.

    res.json({ message: `Evidence ${action}d`, evidence });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;