const express = require('express');
const { Tournament, User, Transaction } = require('../config/database');
const { auth } = require('../middleware/auth');
const { generateBracket } = require('../utils/bracketGenerator');

const router = express.Router();

// Get all tournaments
router.get('/', async (req, res) => {
  try {
    const tournaments = await Tournament.find()
      .sort({ createdAt: -1 })
      .populate('participants.userId', 'username profile');
    
    res.json(tournaments);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get featured tournaments
router.get('/featured', async (req, res) => {
  try {
    const tournaments = await Tournament.find({ status: 'upcoming' })
      .sort({ prizePool: -1 })
      .limit(3)
      .populate('participants.userId', 'username');
    
    res.json(tournaments);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get tournament by ID
router.get('/:id', async (req, res) => {
  try {
    const tournament = await Tournament.findOne({ id: req.params.id })
      .populate('participants.userId', 'username profile')
      .populate('winner', 'username');
    
    if (!tournament) {
      return res.status(404).json({ message: 'Tournament not found' });
    }
    
    res.json(tournament);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create tournament
router.post('/', auth, async (req, res) => {
  try {
    const {
      name,
      game,
      type,
      prizePool,
      entryFee,
      maxParticipants,
      startTime,
      rules
    } = req.body;

    // Generate tournament ID
    const tournamentId = 'T' + Date.now().toString(36).toUpperCase().slice(-8);

    const tournament = new Tournament({
      id: tournamentId,
      name,
      game,
      type,
      prizePool: Number(prizePool),
      entryFee: Number(entryFee),
      maxParticipants: Number(maxParticipants),
      startTime: new Date(startTime),
      rules,
      createdBy: req.user._id
    });

    await tournament.save();
    res.status(201).json(tournament);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Join tournament
router.post('/:id/join', auth, async (req, res) => {
  try {
    const tournament = await Tournament.findOne({ id: req.params.id });
    
    if (!tournament) {
      return res.status(404).json({ message: 'Tournament not found' });
    }

    if (tournament.status !== 'upcoming') {
      return res.status(400).json({ message: 'Tournament is not open for registration' });
    }

    if (tournament.currentParticipants >= tournament.maxParticipants) {
      return res.status(400).json({ message: 'Tournament is full' });
    }

    // Check if user already joined
    const alreadyJoined = tournament.participants.some(
      p => p.userId.toString() === req.user._id.toString()
    );
    
    if (alreadyJoined) {
      return res.status(400).json({ message: 'Already joined this tournament' });
    }

    // Check balance
    if (req.user.balance < tournament.entryFee) {
      return res.status(400).json({ message: 'Insufficient balance' });
    }

    // Deduct entry fee
    req.user.balance -= tournament.entryFee;
    await req.user.save();

    // Add participant
    tournament.participants.push({
      userId: req.user._id,
      username: req.user.username
    });
    
    tournament.currentParticipants++;

    // If tournament is full, generate bracket and start
    if (tournament.currentParticipants >= tournament.maxParticipants) {
      tournament.status = 'active';
      tournament.bracket = generateBracket(tournament.participants);
    }

    await tournament.save();

    // Record transaction
    const transaction = new Transaction({
      userId: req.user._id,
      type: 'tournament_entry',
      amount: tournament.entryFee,
      status: 'completed',
      description: `Entry fee for ${tournament.name}`
    });
    
    await transaction.save();

    res.json({ message: 'Successfully joined tournament', tournament });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update tournament bracket (admin)
router.put('/:id/bracket', auth, async (req, res) => {
  try {
    if (!req.user.isAdmin) {
      return res.status(403).json({ message: 'Admin access required' });
    }

    const tournament = await Tournament.findOne({ id: req.params.id });
    
    if (!tournament) {
      return res.status(404).json({ message: 'Tournament not found' });
    }

    tournament.bracket = req.body.bracket;
    await tournament.save();

    res.json(tournament);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;