const express = require('express');
const { Transaction, User } = require('../config/database');
const { auth } = require('../middleware/auth');
const { processDeposit, processWithdrawal } = require('../utils/payment');

const router = express.Router();

// Get wallet balance and transactions
router.get('/', auth, async (req, res) => {
  try {
    const transactions = await Transaction.find({ userId: req.user._id })
      .sort({ createdAt: -1 })
      .limit(50);

    res.json({
      balance: req.user.balance,
      transactions
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Deposit request
router.post('/deposit', auth, async (req, res) => {
  try {
    const { amount, method } = req.body;

    if (amount <= 0) {
      return res.status(400).json({ message: 'Invalid amount' });
    }

    // Create pending transaction
    const transaction = new Transaction({
      userId: req.user._id,
      type: 'deposit',
      amount: Number(amount),
      method,
      status: 'pending',
      reference: 'DEP_' + Date.now().toString(36).toUpperCase()
    });

    await transaction.save();

    // Process payment based on method
    const paymentResult = await processDeposit(transaction, method);

    res.json({
      message: 'Deposit initiated',
      transaction,
      paymentUrl: paymentResult.paymentUrl
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Withdrawal request
router.post('/withdraw', auth, async (req, res) => {
  try {
    const { amount, method, accountDetails } = req.body;

    if (amount <= 0 || amount > req.user.balance) {
      return res.status(400).json({ message: 'Invalid amount' });
    }

    // Check minimum withdrawal
    if (amount < 10) { // $10 minimum
      return res.status(400).json({ message: 'Minimum withdrawal is $10' });
    }

    // Deduct amount immediately
    req.user.balance -= amount;
    await req.user.save();

    // Create withdrawal transaction
    const transaction = new Transaction({
      userId: req.user._id,
      type: 'withdrawal',
      amount: Number(amount),
      method,
      status: 'pending',
      reference: 'WD_' + Date.now().toString(36).toUpperCase(),
      metadata: { accountDetails }
    });

    await transaction.save();

    res.json({
      message: 'Withdrawal request submitted for admin approval',
      transaction
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Transfer to another user
router.post('/transfer', auth, async (req, res) => {
  try {
    const { toUsername, amount } = req.body;

    if (amount <= 0 || amount > req.user.balance) {
      return res.status(400).json({ message: 'Invalid amount' });
    }

    const recipient = await User.findOne({ username: toUsername });
    
    if (!recipient) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (recipient._id.toString() === req.user._id.toString()) {
      return res.status(400).json({ message: 'Cannot transfer to yourself' });
    }

    // Process transfer
    req.user.balance -= amount;
    recipient.balance += amount;

    await req.user.save();
    await recipient.save();

    // Record transactions for both users
    const senderTransaction = new Transaction({
      userId: req.user._id,
      type: 'transfer',
      amount: Number(amount),
      status: 'completed',
      toUser: recipient._id,
      description: `Transfer to ${recipient.username}`
    });

    const recipientTransaction = new Transaction({
      userId: recipient._id,
      type: 'transfer',
      amount: Number(amount),
      status: 'completed',
      toUser: req.user._id,
      description: `Transfer from ${req.user.username}`
    });

    await senderTransaction.save();
    await recipientTransaction.save();

    res.json({
      message: `Successfully transferred $${amount} to ${recipient.username}`,
      newBalance: req.user.balance
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Webhook for payment providers
router.post('/webhook/:provider', async (req, res) => {
  try {
    const { provider } = req.params;
    
    // Verify webhook signature based on provider
    // This is a simplified version - implement proper verification for each provider
    
    const { reference, status, amount } = req.body;

    const transaction = await Transaction.findOne({ reference });
    
    if (!transaction) {
      return res.status(404).json({ message: 'Transaction not found' });
    }

    if (status === 'success' && transaction.status === 'pending') {
      // Update transaction status
      transaction.status = 'completed';
      await transaction.save();

      // Credit user's wallet
      const user = await User.findById(transaction.userId);
      user.balance += transaction.amount;
      await user.save();
    }

    res.json({ message: 'Webhook processed' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Webhook processing failed' });
  }
});

module.exports = router;