const mongoose = require('mongoose');

const participantSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  username: {
    type: String,
    required: true
  },
  teamName: {
    type: String,
    default: null
  },
  joinedAt: {
    type: Date,
    default: Date.now
  },
  position: {
    type: Number,
    default: null
  },
  score: {
    type: Number,
    default: 0
  },
  kills: {
    type: Number,
    default: 0
  },
  deaths: {
    type: Number,
    default: 0
  },
  assists: {
    type: Number,
    default: 0
  },
  isDisqualified: {
    type: Boolean,
    default: false
  },
  disqualificationReason: {
    type: String,
    default: null
  }
});

const matchSchema = new mongoose.Schema({
  matchId: {
    type: String,
    required: true
  },
  round: {
    type: Number,
    required: true
  },
  player1: {
    type: String,
    required: true
  },
  player2: {
    type: String,
    required: true
  },
  winner: {
    type: String,
    default: null
  },
  score: {
    player1: { type: Number, default: 0 },
    player2: { type: Number, default: 0 }
  },
  status: {
    type: String,
    enum: ['pending', 'live', 'completed', 'cancelled'],
    default: 'pending'
  },
  startTime: {
    type: Date,
    default: null
  },
  endTime: {
    type: Date,
    default: null
  },
  evidence: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'AntiCheat'
  }]
});

const bracketSchema = new mongoose.Schema({
  rounds: [{
    round: {
      type: Number,
      required: true
    },
    matches: [matchSchema]
  }],
  finalWinner: {
    type: String,
    default: null
  },
  isCompleted: {
    type: Boolean,
    default: false
  }
});

const tournamentSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
    unique: true
  },
  name: {
    type: String,
    required: [true, 'Tournament name is required'],
    trim: true,
    maxlength: [100, 'Tournament name cannot exceed 100 characters']
  },
  game: {
    type: String,
    required: [true, 'Game is required'],
    enum: ['COD Mobile', 'Free Fire', 'Blood Strike', 'PUBG Mobile', 'Fortnite', 'Valorant Mobile']
  },
  type: {
    type: String,
    required: [true, 'Tournament type is required'],
    enum: ['solo', 'duo', 'squad', 'team'],
    default: 'solo'
  },
  prizePool: {
    type: Number,
    required: [true, 'Prize pool is required'],
    min: [0, 'Prize pool cannot be negative']
  },
  entryFee: {
    type: Number,
    required: [true, 'Entry fee is required'],
    min: [0, 'Entry fee cannot be negative']
  },
  maxParticipants: {
    type: Number,
    required: [true, 'Max participants is required'],
    min: [2, 'Minimum 2 participants required'],
    max: [1000, 'Maximum 1000 participants allowed']
  },
  currentParticipants: {
    type: Number,
    default: 0
  },
  participants: [participantSchema],
  startTime: {
    type: Date,
    required: [true, 'Start time is required']
  },
  endTime: {
    type: Date,
    default: null
  },
  rules: {
    type: String,
    maxlength: [2000, 'Rules cannot exceed 2000 characters'],
    default: 'Standard tournament rules apply.'
  },
  status: {
    type: String,
    enum: ['upcoming', 'registration', 'active', 'finished', 'cancelled'],
    default: 'upcoming'
  },
  bracket: bracketSchema,
  winner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  runnerUp: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  thirdPlace: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  prizeDistribution: {
    first: { type: Number, default: 0.5 }, // 50%
    second: { type: Number, default: 0.3 }, // 30%
    third: { type: Number, default: 0.2 }   // 20%
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  admins: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  streamUrl: {
    type: String,
    default: null
  },
  tags: [{
    type: String,
    trim: true
  }],
  settings: {
    autoStart: {
      type: Boolean,
      default: true
    },
    allowSpectators: {
      type: Boolean,
      default: true
    },
    requireVerification: {
      type: Boolean,
      default: true
    },
    maxTeamSize: {
      type: Number,
      default: 1
    },
    minTeamSize: {
      type: Number,
      default: 1
    }
  },
  metadata: {
    views: {
      type: Number,
      default: 0
    },
    likes: {
      type: Number,
      default: 0
    },
    shares: {
      type: Number,
      default: 0
    }
  }
}, {
  timestamps: true
});

// Indexes for better performance
tournamentSchema.index({ id: 1 });
tournamentSchema.index({ status: 1 });
tournamentSchema.index({ game: 1 });
tournamentSchema.index({ startTime: 1 });
tournamentSchema.index({ 'participants.userId': 1 });
tournamentSchema.index({ prizePool: -1 });
tournamentSchema.index({ createdBy: 1 });

// Virtual for checking if tournament is full
tournamentSchema.virtual('isFull').get(function() {
  return this.currentParticipants >= this.maxParticipants;
});

// Virtual for time until start
tournamentSchema.virtual('timeUntilStart').get(function() {
  return this.startTime - new Date();
});

// Method to add participant
tournamentSchema.methods.addParticipant = function(userId, username, teamName = null) {
  if (this.isFull) {
    throw new Error('Tournament is full');
  }
  
  if (this.status !== 'upcoming' && this.status !== 'registration') {
    throw new Error('Tournament registration is closed');
  }
  
  const existingParticipant = this.participants.find(p => 
    p.userId.toString() === userId.toString()
  );
  
  if (existingParticipant) {
    throw new Error('User already registered for this tournament');
  }
  
  this.participants.push({
    userId,
    username,
    teamName
  });
  
  this.currentParticipants += 1;
  
  return this.save();
};

// Method to remove participant
tournamentSchema.methods.removeParticipant = function(userId) {
  const participantIndex = this.participants.findIndex(p => 
    p.userId.toString() === userId.toString()
  );
  
  if (participantIndex === -1) {
    throw new Error('Participant not found');
  }
  
  this.participants.splice(participantIndex, 1);
  this.currentParticipants -= 1;
  
  return this.save();
};

// Method to start tournament
tournamentSchema.methods.startTournament = function() {
  if (this.status !== 'upcoming' && this.status !== 'registration') {
    throw new Error('Tournament cannot be started in current status');
  }
  
  if (this.currentParticipants < 2) {
    throw new Error('Need at least 2 participants to start tournament');
  }
  
  this.status = 'active';
  return this.save();
};

// Method to finish tournament
tournamentSchema.methods.finishTournament = function(winnerId, runnerUpId = null, thirdPlaceId = null) {
  if (this.status !== 'active') {
    throw new Error('Only active tournaments can be finished');
  }
  
  this.status = 'finished';
  this.winner = winnerId;
  this.runnerUp = runnerUpId;
  this.thirdPlace = thirdPlaceId;
  this.endTime = new Date();
  
  return this.save();
};

// Method to update participant score
tournamentSchema.methods.updateParticipantScore = function(userId, score, kills = 0, deaths = 0, assists = 0) {
  const participant = this.participants.find(p => 
    p.userId.toString() === userId.toString()
  );
  
  if (!participant) {
    throw new Error('Participant not found');
  }
  
  participant.score = score;
  participant.kills = kills;
  participant.deaths = deaths;
  participant.assists = assists;
  
  return this.save();
};

// Static method to get featured tournaments
tournamentSchema.statics.getFeatured = function() {
  return this.find({ 
    status: { $in: ['upcoming', 'registration'] },
    startTime: { $gt: new Date() }
  })
  .sort({ prizePool: -1, startTime: 1 })
  .limit(6)
  .populate('participants.userId', 'username profile')
  .populate('winner', 'username');
};

// Static method to get tournaments by game
tournamentSchema.statics.getByGame = function(game, limit = 10) {
  return this.find({ 
    game,
    status: { $in: ['upcoming', 'registration'] }
  })
  .sort({ startTime: 1 })
  .limit(limit)
  .populate('participants.userId', 'username');
};

module.exports = mongoose.model('Tournament', tournamentSchema);