const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User ID is required']
  },
  type: {
    type: String,
    required: [true, 'Transaction type is required'],
    enum: [
      'deposit', 
      'withdrawal', 
      'bet', 
      'tournament_entry', 
      'winning', 
      'refund', 
      'transfer', 
      'referral', 
      'bonus',
      'fee',
      'adjustment'
    ]
  },
  amount: {
    type: Number,
    required: [true, 'Amount is required'],
    min: [0.01, 'Amount must be greater than 0']
  },
  method: {
    type: String,
    required: function() {
      return ['deposit', 'withdrawal'].includes(this.type);
    },
    enum: ['paystack', 'flutterwave', 'stripe', 'paypal', 'bank', 'crypto', 'wallet']
  },
  status: {
    type: String,
    enum: ['pending', 'completed', 'failed', 'cancelled', 'processing'],
    default: 'pending'
  },
  reference: {
    type: String,
    required: true,
    unique: true
  },
  externalReference: {
    type: String,
    default: null
  },
  toUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  fromUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  description: {
    type: String,
    maxlength: [500, 'Description cannot exceed 500 characters'],
    default: ''
  },
  metadata: {
    tournamentId: {
      type: String,
      default: null
    },
    tournamentName: {
      type: String,
      default: null
    },
    betId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Bet',
      default: null
    },
    matchId: {
      type: String,
      default: null
    },
    accountDetails: mongoose.Schema.Types.Mixed,
    paymentUrl: {
      type: String,
      default: null
    },
    fee: {
      type: Number,
      default: 0
    },
    netAmount: {
      type: Number,
      default: 0
    },
    currency: {
      type: String,
      default: 'USD'
    },
    exchangeRate: {
      type: Number,
      default: 1
    }
  },
  processedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  processedAt: {
    type: Date,
    default: null
  },
  failureReason: {
    type: String,
    default: null
  },
  ipAddress: {
    type: String,
    default: null
  },
  userAgent: {
    type: String,
    default: null
  }
}, {
  timestamps: true
});

// Indexes for better performance
transactionSchema.index({ userId: 1 });
transactionSchema.index({ reference: 1 });
transactionSchema.index({ type: 1 });
transactionSchema.index({ status: 1 });
transactionSchema.index({ createdAt: -1 });
transactionSchema.index({ userId: 1, type: 1 });
transactionSchema.index({ userId: 1, status: 1 });
transactionSchema.index({ externalReference: 1 });
transactionSchema.index({ 'metadata.tournamentId': 1 });

// Pre-save middleware to generate reference and calculate net amount
transactionSchema.pre('save', function(next) {
  if (this.isNew && !this.reference) {
    const prefix = this.type.substring(0, 3).toUpperCase();
    this.reference = `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  }
  
  // Calculate net amount for withdrawals (amount - fee)
  if (this.type === 'withdrawal' && this.metadata.fee) {
    this.metadata.netAmount = this.amount - this.metadata.fee;
  } else {
    this.metadata.netAmount = this.amount;
  }
  
  next();
});

// Method to complete transaction
transactionSchema.methods.complete = function(processedBy = null, externalRef = null) {
  if (this.status !== 'pending' && this.status !== 'processing') {
    throw new Error('Transaction cannot be completed in current status');
  }
  
  this.status = 'completed';
  this.processedAt = new Date();
  this.processedBy = processedBy;
  
  if (externalRef) {
    this.externalReference = externalRef;
  }
  
  return this.save();
};

// Method to fail transaction
transactionSchema.methods.fail = function(reason, processedBy = null) {
  if (this.status === 'completed' || this.status === 'cancelled') {
    throw new Error('Completed or cancelled transactions cannot be failed');
  }
  
  this.status = 'failed';
  this.failureReason = reason;
  this.processedAt = new Date();
  this.processedBy = processedBy;
  
  return this.save();
};

// Method to cancel transaction
transactionSchema.methods.cancel = function(reason = null, processedBy = null) {
  if (this.status === 'completed' || this.status === 'failed') {
    throw new Error('Completed or failed transactions cannot be cancelled');
  }
  
  this.status = 'cancelled';
  this.failureReason = reason;
  this.processedAt = new Date();
  this.processedBy = processedBy;
  
  return this.save();
};

// Static method to get user transaction history
transactionSchema.statics.getUserHistory = function(userId, limit = 50, page = 1) {
  const skip = (page - 1) * limit;
  
  return this.find({
    $or: [
      { userId },
      { toUser: userId }
    ]
  })
  .sort({ createdAt: -1 })
  .skip(skip)
  .limit(limit)
  .populate('userId', 'username')
  .populate('toUser', 'username')
  .populate('fromUser', 'username')
  .populate('processedBy', 'username');
};

// Static method to get pending transactions
transactionSchema.statics.getPending = function(type = null) {
  const query = { status: 'pending' };
  if (type) {
    query.type = type;
  }
  
  return this.find(query)
  .sort({ createdAt: 1 })
  .populate('userId', 'username email')
  .populate('processedBy', 'username');
};

// Static method to calculate user balance from transactions
transactionSchema.statics.calculateUserBalance = async function(userId) {
  const result = await this.aggregate([
    {
      $match: {
        $or: [
          { userId: mongoose.Types.ObjectId(userId) },
          { toUser: mongoose.Types.ObjectId(userId) }
        ],
        status: 'completed'
      }
    },
    {
      $project: {
        credit: {
          $cond: {
            if: {
              $or: [
                { $eq: ['$type', 'deposit'] },
                { $eq: ['$type', 'winning'] },
                { $eq: ['$type', 'refund'] },
                { $eq: ['$type', 'referral'] },
                { $eq: ['$type', 'bonus'] },
                { $eq: ['$type', 'adjustment'] },
                { 
                  $and: [
                    { $eq: ['$type', 'transfer'] },
                    { $eq: ['$toUser', mongoose.Types.ObjectId(userId)] }
                  ]
                }
              ]
            },
            then: '$amount',
            else: 0
          }
        },
        debit: {
          $cond: {
            if: {
              $or: [
                { $eq: ['$type', 'withdrawal'] },
                { $eq: ['$type', 'bet'] },
                { $eq: ['$type', 'tournament_entry'] },
                { $eq: ['$type', 'fee'] },
                { 
                  $and: [
                    { $eq: ['$type', 'transfer'] },
                    { $eq: ['$userId', mongoose.Types.ObjectId(userId)] },
                    { $ne: ['$toUser', mongoose.Types.ObjectId(userId)] }
                  ]
                }
              ]
            },
            then: '$amount',
            else: 0
          }
        }
      }
    },
    {
      $group: {
        _id: null,
        totalCredit: { $sum: '$credit' },
        totalDebit: { $sum: '$debit' }
      }
    }
  ]);
  
  if (result.length > 0) {
    return result[0].totalCredit - result[0].totalDebit;
  }
  
  return 0;
};

// Virtual for isCredit
transactionSchema.virtual('isCredit').get(function() {
  const creditTypes = ['deposit', 'winning', 'refund', 'referral', 'bonus', 'adjustment'];
  const isTransferCredit = this.type === 'transfer' && this.toUser && this.toUser.toString() !== this.userId.toString();
  
  return creditTypes.includes(this.type) || isTransferCredit;
});

// Virtual for isDebit
transactionSchema.virtual('isDebit').get(function() {
  const debitTypes = ['withdrawal', 'bet', 'tournament_entry', 'fee'];
  const isTransferDebit = this.type === 'transfer' && this.userId && (!this.toUser || this.toUser.toString() === this.userId.toString());
  
  return debitTypes.includes(this.type) || isTransferDebit;
});

module.exports = mongoose.model('Transaction', transactionSchema);