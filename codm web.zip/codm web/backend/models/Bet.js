const mongoose = require('mongoose');

const betSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User ID is required']
  },
  matchId: {
    type: String,
    required: [true, 'Match ID is required']
  },
  tournamentId: {
    type: String,
    required: [true, 'Tournament ID is required']
  },
  tournamentName: {
    type: String,
    required: true
  },
  selection: {
    type: String,
    required: [true, 'Selection is required']
  },
  odds: {
    type: Number,
    required: [true, 'Odds are required'],
    min: [1.01, 'Odds must be greater than 1.00']
  },
  amount: {
    type: Number,
    required: [true, 'Bet amount is required'],
    min: [1, 'Minimum bet amount is $1']
  },
  potentialWin: {
    type: Number,
    required: true
  },
  status: {
    type: String,
    enum: ['active', 'won', 'lost', 'cancelled', 'refunded'],
    default: 'active'
  },
  result: {
    type: String,
    enum: ['win', 'loss', 'push', 'cancelled'],
    default: null
  },
  settledAt: {
    type: Date,
    default: null
  },
  settledBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  matchResult: {
    type: String,
    default: null
  },
  betType: {
    type: String,
    enum: ['match_winner', 'tournament_winner', 'top_scorer', 'first_blood'],
    default: 'match_winner'
  },
  market: {
    type: String,
    default: 'moneyline'
  },
  betSlipId: {
    type: String,
    default: null
  },
  platformCommission: {
    type: Number,
    default: 0.05 // 5% platform commission
  },
  actualPayout: {
    type: Number,
    default: 0
  },
  metadata: {
    ipAddress: String,
    userAgent: String,
    deviceId: String
  }
}, {
  timestamps: true
});

// Indexes for better performance
betSchema.index({ userId: 1 });
betSchema.index({ matchId: 1 });
betSchema.index({ tournamentId: 1 });
betSchema.index({ status: 1 });
betSchema.index({ createdAt: -1 });
betSchema.index({ settledAt: -1 });
betSchema.index({ userId: 1, status: 1 });
betSchema.index({ betSlipId: 1 });

// Pre-save middleware to calculate potential win
betSchema.pre('save', function(next) {
  if (this.isModified('amount') || this.isModified('odds')) {
    this.potentialWin = parseFloat((this.amount * this.odds).toFixed(2));
  }
  next();
});

// Method to settle bet
betSchema.methods.settle = function(result, settledBy = null, matchResult = null) {
  if (this.status !== 'active') {
    throw new Error('Bet is already settled');
  }
  
  this.status = result === 'win' ? 'won' : 'lost';
  this.result = result;
  this.settledAt = new Date();
  this.settledBy = settledBy;
  this.matchResult = matchResult;
  
  if (result === 'win') {
    // Calculate actual payout after commission
    const commission = this.amount * this.platformCommission;
    this.actualPayout = this.potentialWin - commission;
  } else {
    this.actualPayout = 0;
  }
  
  return this.save();
};

// Method to cancel bet
betSchema.methods.cancel = function(cancelledBy = null) {
  if (this.status !== 'active') {
    throw new Error('Only active bets can be cancelled');
  }
  
  this.status = 'cancelled';
  this.result = 'cancelled';
  this.settledAt = new Date();
  this.settledBy = cancelledBy;
  
  return this.save();
};

// Method to refund bet
betSchema.methods.refund = function(refundedBy = null) {
  if (this.status !== 'active') {
    throw new Error('Only active bets can be refunded');
  }
  
  this.status = 'refunded';
  this.result = 'cancelled';
  this.settledAt = new Date();
  this.settledBy = refundedBy;
  this.actualPayout = this.amount; // Refund original amount
  
  return this.save();
};

// Static method to get active bets by user
betSchema.statics.getActiveBetsByUser = function(userId) {
  return this.find({
    userId,
    status: 'active'
  })
  .sort({ createdAt: -1 })
  .populate('userId', 'username')
  .populate('settledBy', 'username');
};

// Static method to get bet history by user
betSchema.statics.getBetHistoryByUser = function(userId, limit = 50) {
  return this.find({
    userId,
    status: { $in: ['won', 'lost', 'cancelled', 'refunded'] }
  })
  .sort({ settledAt: -1, createdAt: -1 })
  .limit(limit)
  .populate('userId', 'username')
  .populate('settledBy', 'username');
};

// Static method to calculate user betting statistics
betSchema.statics.getUserBettingStats = async function(userId) {
  const stats = await this.aggregate([
    { $match: { userId: mongoose.Types.ObjectId(userId) } },
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 },
        totalAmount: { $sum: '$amount' },
        totalPayout: { $sum: '$actualPayout' }
      }
    }
  ]);
  
  const result = {
    totalBets: 0,
    activeBets: 0,
    wonBets: 0,
    lostBets: 0,
    totalWagered: 0,
    totalWon: 0,
    netProfit: 0
  };
  
  stats.forEach(stat => {
    result.totalBets += stat.count;
    result.totalWagered += stat.totalAmount;
    
    if (stat._id === 'active') {
      result.activeBets = stat.count;
    } else if (stat._id === 'won') {
      result.wonBets = stat.count;
      result.totalWon += stat.totalPayout;
    } else if (stat._id === 'lost') {
      result.lostBets = stat.count;
    }
  });
  
  result.netProfit = result.totalWon - result.totalWagered;
  
  return result;
};

// Virtual for bet duration
betSchema.virtual('duration').get(function() {
  if (this.settledAt && this.createdAt) {
    return this.settledAt - this.createdAt;
  }
  return null;
});

// Virtual for isSettled
betSchema.virtual('isSettled').get(function() {
  return this.status !== 'active';
});

module.exports = mongoose.model('Bet', betSchema);