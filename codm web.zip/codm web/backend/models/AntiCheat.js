const mongoose = require('mongoose');

const evidenceAnalysisSchema = new mongoose.Schema({
  aiConfidence: {
    type: Number,
    default: 0,
    min: 0,
    max: 1
  },
  suspiciousElements: [{
    type: String,
    trim: true
  }],
  detectedPatterns: [{
    pattern: String,
    confidence: Number,
    description: String
  }],
  ocrText: {
    type: String,
    default: ''
  },
  imageHash: {
    type: String,
    default: ''
  },
  metadata: mongoose.Schema.Types.Mixed
});

const antiCheatSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User ID is required']
  },
  username: {
    type: String,
    required: true
  },
  tournamentId: {
    type: String,
    required: [true, 'Tournament ID is required']
  },
  tournamentName: {
    type: String,
    required: true
  },
  matchId: {
    type: String,
    default: null
  },
  evidenceType: {
    type: String,
    required: [true, 'Evidence type is required'],
    enum: ['screenshot', 'video', 'log_file', 'stream_recording']
  },
  filename: {
    type: String,
    required: [true, 'Filename is required']
  },
  fileUrl: {
    type: String,
    required: [true, 'File URL is required']
  },
  fileSize: {
    type: Number,
    default: 0
  },
  fileHash: {
    type: String,
    default: ''
  },
  mimeType: {
    type: String,
    default: ''
  },
  description: {
    type: String,
    maxlength: [1000, 'Description cannot exceed 1000 characters'],
    default: ''
  },
  status: {
    type: String,
    enum: ['pending', 'under_review', 'approved', 'rejected', 'escalated'],
    default: 'pending'
  },
  severity: {
    type: String,
    enum: ['low', 'medium', 'high', 'critical'],
    default: 'medium'
  },
  analysis: evidenceAnalysisSchema,
  adminNotes: {
    type: String,
    maxlength: [2000, 'Admin notes cannot exceed 2000 characters'],
    default: ''
  },
  reviewedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  reviewedAt: {
    type: Date,
    default: null
  },
  decision: {
    type: String,
    enum: ['clean', 'warning_issued', 'disqualified', 'banned', 'suspended', 'no_action'],
    default: null
  },
  decisionReason: {
    type: String,
    maxlength: [1000, 'Decision reason cannot exceed 1000 characters'],
    default: ''
  },
  penaltyDuration: {
    type: Number, // Duration in days
    default: 0
  },
  penaltyExpires: {
    type: Date,
    default: null
  },
  appealAllowed: {
    type: Boolean,
    default: true
  },
  appealStatus: {
    type: String,
    enum: ['none', 'pending', 'approved', 'rejected'],
    default: 'none'
  },
  appealNotes: {
    type: String,
    maxlength: [2000, 'Appeal notes cannot exceed 2000 characters'],
    default: ''
  },
  appealReviewedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  appealReviewedAt: {
    type: Date,
    default: null
  },
  relatedEvidence: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'AntiCheat'
  }],
  tags: [{
    type: String,
    trim: true
  }],
  metadata: {
    ipAddress: String,
    userAgent: String,
    uploadSource: {
      type: String,
      enum: ['player', 'admin', 'system', 'automated'],
      default: 'player'
    },
    gameVersion: String,
    deviceInfo: mongoose.Schema.Types.Mixed
  }
}, {
  timestamps: true
});

// Indexes for better performance
antiCheatSchema.index({ userId: 1 });
antiCheatSchema.index({ tournamentId: 1 });
antiCheatSchema.index({ status: 1 });
antiCheatSchema.index({ severity: 1 });
antiCheatSchema.index({ createdAt: -1 });
antiCheatSchema.index({ reviewedAt: -1 });
antiCheatSchema.index({ 'analysis.aiConfidence': -1 });
antiCheatSchema.index({ userId: 1, status: 1 });
antiCheatSchema.index({ tournamentId: 1, status: 1 });

// Pre-save middleware to set username
antiCheatSchema.pre('save', async function(next) {
  if (this.isNew && !this.username) {
    try {
      const User = mongoose.model('User');
      const user = await User.findById(this.userId).select('username');
      if (user) {
        this.username = user.username;
      }
    } catch (error) {
      // Continue without username if user not found
    }
  }
  
  if (this.isNew && !this.tournamentName) {
    try {
      const Tournament = mongoose.model('Tournament');
      const tournament = await Tournament.findOne({ id: this.tournamentId }).select('name');
      if (tournament) {
        this.tournamentName = tournament.name;
      }
    } catch (error) {
      // Continue without tournament name if not found
    }
  }
  
  // Set penalty expiration if penalty duration is set
  if (this.isModified('penaltyDuration') && this.penaltyDuration > 0) {
    this.penaltyExpires = new Date(Date.now() + this.penaltyDuration * 24 * 60 * 60 * 1000);
  }
  
  next();
});

// Method to approve evidence
antiCheatSchema.methods.approve = function(reviewedBy, notes = '', decision = 'disqualified', penaltyDuration = 0) {
  if (this.status === 'approved' || this.status === 'rejected') {
    throw new Error('Evidence has already been reviewed');
  }
  
  this.status = 'approved';
  this.reviewedBy = reviewedBy;
  this.reviewedAt = new Date();
  this.adminNotes = notes;
  this.decision = decision;
  this.penaltyDuration = penaltyDuration;
  
  if (penaltyDuration > 0) {
    this.penaltyExpires = new Date(Date.now() + penaltyDuration * 24 * 60 * 60 * 1000);
  }
  
  return this.save();
};

// Method to reject evidence
antiCheatSchema.methods.reject = function(reviewedBy, notes = '') {
  if (this.status === 'approved' || this.status === 'rejected') {
    throw new Error('Evidence has already been reviewed');
  }
  
  this.status = 'rejected';
  this.reviewedBy = reviewedBy;
  this.reviewedAt = new Date();
  this.adminNotes = notes;
  this.decision = 'no_action';
  
  return this.save();
};

// Method to escalate evidence
antiCheatSchema.methods.escalate = function(reviewedBy, notes = '') {
  if (this.status !== 'pending' && this.status !== 'under_review') {
    throw new Error('Only pending or under review evidence can be escalated');
  }
  
  this.status = 'escalated';
  this.reviewedBy = reviewedBy;
  this.reviewedAt = new Date();
  this.adminNotes = notes;
  this.severity = 'high';
  
  return this.save();
};

// Method to submit appeal
antiCheatSchema.methods.submitAppeal = function(notes = '') {
  if (this.status !== 'approved') {
    throw new Error('Only approved evidence can be appealed');
  }
  
  if (!this.appealAllowed) {
    throw new Error('Appeals are not allowed for this case');
  }
  
  if (this.appealStatus !== 'none') {
    throw new Error('Appeal has already been submitted');
  }
  
  this.appealStatus = 'pending';
  this.appealNotes = notes;
  
  return this.save();
};

// Method to review appeal
antiCheatSchema.methods.reviewAppeal = function(approved, reviewedBy, notes = '') {
  if (this.appealStatus !== 'pending') {
    throw new Error('No pending appeal to review');
  }
  
  this.appealStatus = approved ? 'approved' : 'rejected';
  this.appealReviewedBy = reviewedBy;
  this.appealReviewedAt = new Date();
  
  if (notes) {
    this.appealNotes += `\n\nAppeal Review: ${notes}`;
  }
  
  // If appeal is approved, reverse the decision
  if (approved) {
    this.status = 'rejected';
    this.decision = 'no_action';
    this.penaltyDuration = 0;
    this.penaltyExpires = null;
  }
  
  return this.save();
};

// Static method to get pending evidence
antiCheatSchema.statics.getPending = function(limit = 50) {
  return this.find({ status: 'pending' })
  .sort({ createdAt: 1 })
  .limit(limit)
  .populate('userId', 'username email profile')
  .populate('reviewedBy', 'username')
  .populate('appealReviewedBy', 'username');
};

// Static method to get evidence by user
antiCheatSchema.statics.getByUser = function(userId, limit = 50) {
  return this.find({ userId })
  .sort({ createdAt: -1 })
  .limit(limit)
  .populate('reviewedBy', 'username')
  .populate('appealReviewedBy', 'username');
};

// Static method to get evidence by tournament
antiCheatSchema.statics.getByTournament = function(tournamentId, limit = 100) {
  return this.find({ tournamentId })
  .sort({ createdAt: -1 })
  .limit(limit)
  .populate('userId', 'username profile')
  .populate('reviewedBy', 'username');
};

// Virtual for isReviewed
antiCheatSchema.virtual('isReviewed').get(function() {
  return this.status === 'approved' || this.status === 'rejected';
});

// Virtual for hasActivePenalty
antiCheatSchema.virtual('hasActivePenalty').get(function() {
  return this.penaltyExpires && this.penaltyExpires > new Date();
});

// Virtual for canAppeal
antiCheatSchema.virtual('canAppeal').get(function() {
  return this.status === 'approved' && 
         this.appealAllowed && 
         this.appealStatus === 'none' &&
         (!this.penaltyExpires || this.penaltyExpires > new Date());
});

module.exports = mongoose.model('AntiCheat', antiCheatSchema);