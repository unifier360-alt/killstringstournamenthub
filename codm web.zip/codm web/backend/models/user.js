const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: [true, 'Username is required'],
    unique: true,
    trim: true,
    minlength: [3, 'Username must be at least 3 characters'],
    maxlength: [20, 'Username cannot exceed 20 characters'],
    match: [/^[a-zA-Z0-9_]+$/, 'Username can only contain letters, numbers, and underscores']
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    trim: true,
    lowercase: true,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [6, 'Password must be at least 6 characters']
  },
  balance: {
    type: Number,
    default: 0,
    min: [0, 'Balance cannot be negative']
  },
  isAdmin: {
    type: Boolean,
    default: false
  },
  isPremium: {
    type: Boolean,
    default: false
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  isBanned: {
    type: Boolean,
    default: false
  },
  profile: {
    codmUID: {
      type: String,
      default: ''
    },
    freeFireUID: {
      type: String,
      default: ''
    },
    bloodStrikeUID: {
      type: String,
      default: ''
    },
    rank: {
      type: String,
      default: 'Rookie'
    },
    avatar: {
      type: String,
      default: ''
    },
    bio: {
      type: String,
      maxlength: [500, 'Bio cannot exceed 500 characters'],
      default: ''
    }
  },
  referralCode: {
    type: String,
    unique: true,
    required: true
  },
  referredBy: {
    type: String,
    default: null
  },
  referralEarnings: {
    type: Number,
    default: 0
  },
  twoFactorEnabled: {
    type: Boolean,
    default: false
  },
  twoFactorSecret: {
    type: String,
    default: null
  },
  lastLogin: {
    type: Date,
    default: null
  },
  loginDevices: [{
    deviceId: String,
    userAgent: String,
    ipAddress: String,
    lastUsed: Date
  }],
  preferences: {
    emailNotifications: {
      type: Boolean,
      default: true
    },
    pushNotifications: {
      type: Boolean,
      default: true
    },
    tournamentReminders: {
      type: Boolean,
      default: true
    },
    betNotifications: {
      type: Boolean,
      default: true
    }
  },
  statistics: {
    tournamentsJoined: {
      type: Number,
      default: 0
    },
    tournamentsWon: {
      type: Number,
      default: 0
    },
    totalEarnings: {
      type: Number,
      default: 0
    },
    totalBets: {
      type: Number,
      default: 0
    },
    successfulBets: {
      type: Number,
      default: 0
    },
    winRate: {
      type: Number,
      default: 0
    }
  }
}, {
  timestamps: true
});

// Index for better query performance
userSchema.index({ email: 1 });
userSchema.index({ username: 1 });
userSchema.index({ referralCode: 1 });
userSchema.index({ 'profile.codmUID': 1 });
userSchema.index({ balance: -1 });
userSchema.index({ 'statistics.totalEarnings': -1 });

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(12);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Compare password method
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Update last login
userSchema.methods.updateLastLogin = function(deviceInfo = {}) {
  this.lastLogin = new Date();
  
  if (deviceInfo.deviceId) {
    const existingDevice = this.loginDevices.find(device => 
      device.deviceId === deviceInfo.deviceId
    );
    
    if (existingDevice) {
      existingDevice.lastUsed = new Date();
      existingDevice.userAgent = deviceInfo.userAgent;
      existingDevice.ipAddress = deviceInfo.ipAddress;
    } else {
      this.loginDevices.push({
        deviceId: deviceInfo.deviceId,
        userAgent: deviceInfo.userAgent,
        ipAddress: deviceInfo.ipAddress,
        lastUsed: new Date()
      });
    }
  }
  
  return this.save();
};

// Add tournament statistics
userSchema.methods.addTournamentResult = function(won = false, earnings = 0) {
  this.statistics.tournamentsJoined += 1;
  
  if (won) {
    this.statistics.tournamentsWon += 1;
  }
  
  if (earnings > 0) {
    this.statistics.totalEarnings += earnings;
  }
  
  return this.save();
};

// Add bet statistics
userSchema.methods.addBetResult = function(won = false, amount = 0) {
  this.statistics.totalBets += 1;
  
  if (won) {
    this.statistics.successfulBets += 1;
  }
  
  // Calculate win rate
  this.statistics.winRate = this.statistics.successfulBets / this.statistics.totalBets * 100;
  
  if (won && amount > 0) {
    this.statistics.totalEarnings += amount;
  }
  
  return this.save();
};

// Virtual for win rate
userSchema.virtual('winRatePercentage').get(function() {
  return this.statistics.totalBets > 0 
    ? (this.statistics.successfulBets / this.statistics.totalBets * 100).toFixed(1)
    : 0;
});

// Method to check if user can withdraw
userSchema.methods.canWithdraw = function(amount) {
  return this.balance >= amount && !this.isBanned;
};

// Method to check if user can join tournament
userSchema.methods.canJoinTournament = function(entryFee) {
  return this.balance >= entryFee && !this.isBanned && this.isVerified;
};

// JSON transformation to remove sensitive data
userSchema.methods.toJSON = function() {
  const user = this.toObject();
  delete user.password;
  delete user.twoFactorSecret;
  delete user.loginDevices;
  return user;
};

module.exports = mongoose.model('User', userSchema);